# Total Site & Block Theme Backup Suite

**Version:** 1.0 Stable (`1.0.0`)  
**Developer:** [androidSuperUser](https://github.com/androidSuperUser)  
**Repository:** [total-site-block-backup](https://github.com/androidSuperUser/total-site-block-backup)  
**Donate:** [Support development via PayPal](https://paypal.me/paymenttomanu)  
**License:** GPL-2.0-or-later

Total Site & Block Theme Backup Suite is a WordPress administrator tool for creating selective ZIP backups and restoring supported site content, installed plugins/themes, and Full Site Editing (FSE) block-theme customizations.

## Features

- **Selective content backups:** choose individual Posts, Pages, and Categories to include.
- **Block-theme customization backups:** supports WordPress block content types including templates, template parts, global styles, navigation, and synced/reusable blocks where available.
- **Theme settings and customizations:** can include supported theme modifications and custom CSS.
- **Plugin and theme selection:** choose installed plugins and themes to include in an archive.
- **ZIP export:** create a ZIP backup for download and/or save it to the server-side backup vault.
- **Server Vault:** manage generated backup archives stored under `wp-content/uploads/tsbb-backups/`, including downloading or deleting vault archives.
- **Restore from a vault archive or uploaded ZIP:** choose which supported components to restore.
- **Chunked archive upload:** uploaded ZIP files are sent to the server in 1 MB chunks to help work around common PHP upload-size limits.
- **Restore conflict options:** overwrite matching items or skip existing items, depending on the selected restore options.
- **ZIP engine fallback:** uses `ZipArchive` when available and includes a PclZip fallback.

## Floating Support Widget

The plugin adds a small, dismissible support card to the public-facing site footer. It credits **androidSuperUser**, links to the developer GitHub profile, and includes a PayPal donation link. The widget uses inline CSS and JavaScript only; it does not load third-party scripts. Visitors can dismiss it for the current page view.

- Developer: [androidSuperUser](https://github.com/androidSuperUser)
- Donate: [PayPal](https://paypal.me/paymenttomanu)

## Installation

1. Download the plugin ZIP release.
2. In WordPress, open **Plugins → Add New Plugin → Upload Plugin**.
3. Select the ZIP and click **Install Now**.
4. Activate **Total Site & Block Theme Backup Suite**.
5. Open **Total Backup** in the WordPress administration menu.

## Creating a backup

1. Open **Total Backup**.
2. Select the content, block customizations, plugins, and themes you want to include.
3. Choose whether to download the archive as well as save it to the Server Vault, or save it to the vault only.
4. Start the export and keep a copy of important backups somewhere separate from the website.

## Restoring a backup

1. Open **Total Backup**.
2. Select a backup already in the Server Vault, or choose a ZIP archive from your device.
3. Select the components you want to restore.
4. Choose the conflict mode: overwrite existing items or skip existing items.
5. Review your selections before starting the restore.

## Important notes

- **Test restores first.** Use a staging site whenever possible and verify the result before restoring on a production website.
- **Keep independent copies.** A backup stored on the same server may be lost if that server or account becomes unavailable.
- **Review the selection carefully.** A selective backup contains the components you chose; do not assume it is a complete, byte-for-byte image of every WordPress database table, upload, configuration file, or server setting.
- **Protect backup archives.** They may contain private site content or configuration data. Store and share them securely, and delete temporary or unneeded archives when appropriate.
- **Compatibility varies.** Available content types and restore results depend on the WordPress version, active theme, installed plugins, and server environment.

## Authorship and support

Made with ♥ by **[androidSuperUser](https://github.com/androidSuperUser)**.

- GitHub profile: <https://github.com/androidSuperUser>
- Donations: <https://paypal.me/paymenttomanu>

The GitHub link identifies the developer and is provided for attribution and project information. The plugin is distributed under the license stated below; recipients may modify GPL-covered code under the terms of that license.

## License

This plugin is licensed under **GNU General Public License v2.0 or later**. See <https://www.gnu.org/licenses/old-licenses/gpl-2.0.html> for the license text.
