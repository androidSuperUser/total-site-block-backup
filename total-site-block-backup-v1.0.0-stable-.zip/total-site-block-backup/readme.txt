=== Total Site & Block Theme Backup Suite ===
Contributors: androidSuperUser
Tags: backup, restore, block-theme, full-site-editing, migration
Stable tag: 1.0.0
Tested up to: 7.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Selective ZIP backup and restore tools for WordPress content, plugins, themes, and supported block-theme customizations.

== Description ==

Total Site & Block Theme Backup Suite lets administrators select Posts, Pages, Categories, supported Full Site Editing block customizations, installed plugins, and themes for ZIP backup and restore.

Features include a server-side backup vault, ZIP download, chunked uploads for restoring larger archives, and overwrite/skip conflict modes.

== Developer support ==

The Total Backup administration panel includes links to the developer GitHub profile and PayPal donation page. The support panel does not appear on the public-facing website.

== Installation ==

1. Upload the plugin ZIP through Plugins > Add New Plugin > Upload Plugin.
2. Install and activate the plugin.
3. Open Total Backup from the WordPress administration menu.

== Authorship ==

Developed by androidSuperUser.
GitHub: https://github.com/androidSuperUser
Donate: https://paypal.me/paymenttomanu

Made with love by androidSuperUser.

== License ==

GPL-2.0-or-later.

A small dismissible developer support box is shown only at the bottom of the Total Backup administration panel, not on public-facing pages.
