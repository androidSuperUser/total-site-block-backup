<?php
/**
 * Plugin Name: Total Site & Block Theme Backup Suite
 * Plugin URI:  https://github.com/androidSuperUser/total-site-block-backup
 * Description: Complete selective backup & restore solution for Posts, Pages, Categories, Plugins, Themes, and Block Theme Customizations (wp_template, wp_template_part, wp_global_styles, wp_navigation, wp_block — specially optimized for Twenty Twenty-Four and Full Site Editing themes). Includes Server Vault + Chunked Upload & PclZip/ZipArchive dual engine so large backups never fail PHP upload limits.
 * Version:     1.0.0
 * Author:      androidSuperUser
 * Author URI:  https://github.com/androidSuperUser
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * License:     GPL-2.0-or-later
 * Text Domain: total-site-block-theme-backup-suite
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Total_Site_Block_Backup_Plugin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_post_tsbb_export_backup', array( $this, 'handle_export_backup' ) );
		add_action( 'admin_post_tsbb_import_backup', array( $this, 'handle_import_backup' ) );
		add_action( 'admin_post_tsbb_delete_vault_file', array( $this, 'handle_delete_vault_file' ) );
		add_action( 'admin_post_tsbb_download_vault_file', array( $this, 'handle_download_vault_file' ) );
		add_action( 'wp_ajax_tsbb_upload_chunk', array( $this, 'ajax_upload_chunk' ) );
	}

	/**
	 * Get (and ensure) dedicated backup vault directory inside wp-content/uploads/tsbb-backups
	 */
	private function get_vault_dir() {
		$upload_dir = wp_upload_dir();
		$vault_dir  = trailingslashit( $upload_dir['basedir'] ) . 'tsbb-backups';
		if ( ! is_dir( $vault_dir ) ) {
			wp_mkdir_p( $vault_dir );
			@file_put_contents( trailingslashit( $vault_dir ) . 'index.php', '<?php // Silence is golden.' );
		}
		return $vault_dir;
	}

	/**
	 * List all existing .zip backup files stored in the Server Vault
	 */
	private function get_vault_backups() {
		$vault_dir = $this->get_vault_dir();
		$files     = glob( trailingslashit( $vault_dir ) . '*.zip' );
		$list      = array();
		if ( is_array( $files ) ) {
			foreach ( $files as $file ) {
				$list[] = array(
					'filename' => basename( $file ),
					'path'     => $file,
					'size'     => filesize( $file ),
					'mtime'    => filemtime( $file ),
				);
			}
			usort( $list, function( $a, $b ) {
				return $b['mtime'] - $a['mtime'];
			} );
		}
		return $list;
	}

	/**
	 * Register Admin Menu
	 */
	public function register_admin_menu() {
		add_menu_page(
			'Total Site Backup & Restore',
			'Total Backup',
			'manage_options',
			'total-site-backup',
			array( $this, 'render_admin_page' ),
			'dashicons-backup',
			75
		);
	}

	/**
	 * Get all items for selective checkboxes in admin UI
	 */
	private function get_selectable_data() {
		$posts = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future' ),
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future' ),
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		) );

		$categories = get_terms( array(
			'taxonomy'   => 'category',
			'hide_empty' => false,
		) );

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all_plugins = get_plugins();
		$all_themes  = wp_get_themes();

		$block_post_types = array(
			'wp_template'      => 'Block Templates (Single Post, Archive, Index, Page, 404, etc.)',
			'wp_template_part' => 'Template Parts (Header, Footer, Sidebar, Post Meta, etc.)',
			'wp_global_styles' => 'Global Styles & theme.json Customizations (Colors, Typography, Layout)',
			'wp_navigation'    => 'Block Navigation Menus',
			'wp_block'         => 'Synced Patterns / Reusable Blocks',
		);

		$block_items = array();
		foreach ( $block_post_types as $pt => $label ) {
			$items = get_posts( array(
				'post_type'      => $pt,
				'post_status'    => array( 'publish', 'draft', 'auto-draft', 'private' ),
				'posts_per_page' => -1,
			) );
			$block_items[ $pt ] = array(
				'label' => $label,
				'items' => $items,
			);
		}

		return array(
			'posts'       => $posts,
			'pages'       => $pages,
			'categories'  => is_wp_error( $categories ) ? array() : $categories,
			'plugins'     => $all_plugins,
			'themes'      => $all_themes,
			'block_items' => $block_items,
		);
	}

	/**
	 * Render the Admin UI
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized access.' );
		}

		$data          = $this->get_selectable_data();
		$vault_backups = $this->get_vault_backups();
		$active_theme  = wp_get_theme();
		$status_msg    = isset( $_GET['tsbb_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['tsbb_msg'] ) ) : '';
		$status_type   = isset( $_GET['tsbb_type'] ) ? sanitize_text_field( wp_unslash( $_GET['tsbb_type'] ) ) : 'success';
		$max_upload    = size_format( wp_max_upload_size() );
		?>
		<div class="wrap tsbb-wrap">
			<h1><span class="dashicons dashicons-backup" style="font-size:28px;width:28px;height:28px;margin-right:8px;"></span> Total Site &amp; Block Theme Backup Suite (v1.0 Stable)</h1>
			<p class="description">Selectively back up and restore Posts, Pages, Categories, Plugins, Themes, and Full Site Editing (FSE) Block Customizations (Header, Footer, Single Post templates, Global Styles — specially built for <strong>Twenty Twenty-Four</strong> and block themes).</p>

			<?php if ( ! empty( $status_msg ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $status_type ); ?> is-dismissible">
					<p><strong><?php echo esc_html( $status_msg ); ?></strong></p>
				</div>
			<?php endif; ?>

			<style>
				.tsbb-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px; }
				@media (max-width: 1024px) { .tsbb-grid { grid-template-columns: 1fr; } }
				.tsbb-card { background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; padding: 20px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
				.tsbb-card h2 { margin-top: 0; padding-bottom: 10px; border-bottom: 1px solid #eee; display: flex; align-items: center; justify-content: space-between; }
				.tsbb-section { margin-bottom: 18px; border: 1px solid #e2e4e7; border-radius: 4px; background: #fafafa; }
				.tsbb-section-header { padding: 10px 14px; background: #f0f0f1; border-bottom: 1px solid #e2e4e7; display: flex; justify-content: space-between; align-items: center; font-weight: 600; }
				.tsbb-list { max-height: 220px; overflow-y: auto; padding: 10px 14px; background: #fff; }
				.tsbb-list label { display: block; margin-bottom: 6px; font-size: 13px; }
				.tsbb-badge { background: #2271b1; color: #fff; border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: normal; margin-left: 6px; }
				.tsbb-badge-theme { background: #135e96; }
				.tsbb-sub-actions { font-size: 12px; font-weight: normal; }
				.tsbb-sub-actions a { text-decoration: none; margin-left: 8px; cursor: pointer; }
				.tsbb-vault-table { width: 100%; border-collapse: collapse; font-size: 13px; }
				.tsbb-vault-table th, .tsbb-vault-table td { text-align: left; padding: 8px; border-bottom: 1px solid #eee; }
				.tsbb-progress-wrap { display: none; margin-top: 12px; background: #f0f0f1; border-radius: 4px; overflow: hidden; border: 1px solid #ccd0d4; }
				.tsbb-progress-bar { height: 22px; background: #2271b1; width: 0%; color: #fff; text-align: center; font-size: 12px; line-height: 22px; transition: width 0.2s; }
			</style>

			<div class="tsbb-grid">
				<!-- EXPORT / BACKUP COLUMN -->
				<div class="tsbb-card">
					<h2>
						<span>1. Create Selective Backup (.zip)</span>
						<span class="tsbb-badge">Active Theme: <?php echo esc_html( $active_theme->get( 'Name' ) ); ?></span>
					</h2>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="tsbb_export_backup" />
						<?php wp_nonce_field( 'tsbb_export_nonce', 'tsbb_nonce' ); ?>

						<!-- POSTS -->
						<div class="tsbb-section">
							<div class="tsbb-section-header">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-posts-list" name="backup_posts_enabled" value="1" checked />
									Posts (<?php echo count( $data['posts'] ); ?>)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-posts-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-posts-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-posts-list">
								<?php if ( empty( $data['posts'] ) ) : ?>
									<em>No posts found.</em>
								<?php else : ?>
									<?php foreach ( $data['posts'] as $p ) : ?>
										<label>
											<input type="checkbox" name="selected_posts[]" value="<?php echo esc_attr( $p->ID ); ?>" checked />
											<?php echo esc_html( $p->post_title ? $p->post_title : '(No Title)' ); ?>
											<code style="font-size:11px;color:#666;">[ID: <?php echo intval( $p->ID ); ?> | <?php echo esc_html( $p->post_status ); ?>]</code>
										</label>
									<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>

						<!-- PAGES -->
						<div class="tsbb-section">
							<div class="tsbb-section-header">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-pages-list" name="backup_pages_enabled" value="1" checked />
									Pages (<?php echo count( $data['pages'] ); ?>)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-pages-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-pages-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-pages-list">
								<?php if ( empty( $data['pages'] ) ) : ?>
									<em>No pages found.</em>
								<?php else : ?>
									<?php foreach ( $data['pages'] as $pg ) : ?>
										<label>
											<input type="checkbox" name="selected_pages[]" value="<?php echo esc_attr( $pg->ID ); ?>" checked />
											<?php echo esc_html( $pg->post_title ? $pg->post_title : '(No Title)' ); ?>
											<code style="font-size:11px;color:#666;">[ID: <?php echo intval( $pg->ID ); ?> | <?php echo esc_html( $pg->post_status ); ?>]</code>
										</label>
									<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>

						<!-- CATEGORIES -->
						<div class="tsbb-section">
							<div class="tsbb-section-header">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-cats-list" name="backup_categories_enabled" value="1" checked />
									Categories (<?php echo count( $data['categories'] ); ?>)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-cats-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-cats-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-cats-list">
								<?php if ( empty( $data['categories'] ) ) : ?>
									<em>No categories found.</em>
								<?php else : ?>
									<?php foreach ( $data['categories'] as $cat ) : ?>
										<label>
											<input type="checkbox" name="selected_categories[]" value="<?php echo esc_attr( $cat->term_id ); ?>" checked />
											<?php echo esc_html( $cat->name ); ?> <code style="font-size:11px;color:#666;">(<?php echo esc_html( $cat->slug ); ?>)</code>
										</label>
									<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>

						<!-- THEME CUSTOMIZATION CODES (TWENTY TWENTY-FOUR / FSE BLOCK TEMPLATES) -->
						<div class="tsbb-section" style="border-color:#2271b1;">
							<div class="tsbb-section-header" style="background:#e5f5fa;">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-blocks-list" name="backup_block_customizations_enabled" value="1" checked />
									Theme Customization Codes (Block Header, Footer, Single Post, Twenty Twenty-Four &amp; FSE)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-blocks-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-blocks-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-blocks-list" style="max-height:300px;">
								<label style="font-weight:600;color:#135e96;margin-bottom:8px;">
									<input type="checkbox" name="include_theme_mods_and_css" value="1" checked />
									Include Theme Mods, Additional CSS (<code>wp_css</code>), Site Logo/Icon &amp; Active Theme Raw Block Files (<code>templates/</code>, <code>parts/</code>, <code>patterns/</code>, <code>theme.json</code>)
								</label>
								<hr style="margin:8px 0;" />
								<?php foreach ( $data['block_items'] as $pt => $group ) : ?>
									<div style="margin-bottom:10px;">
										<strong style="display:block;margin-bottom:4px;color:#1d2327;"><?php echo esc_html( $group['label'] ); ?> (<?php echo count( $group['items'] ); ?>)</strong>
										<?php if ( empty( $group['items'] ) ) : ?>
											<span style="font-size:12px;color:#666;margin-left:18px;">No database overrides saved yet (default theme files will still be backed up if checked above).</span>
										<?php else : ?>
											<?php foreach ( $group['items'] as $bpost ) : ?>
												<?php
												$theme_terms  = wp_get_post_terms( $bpost->ID, 'wp_theme', array( 'fields' => 'slugs' ) );
												$theme_origin = ! empty( $theme_terms ) && ! is_wp_error( $theme_terms ) ? implode( ', ', $theme_terms ) : 'site';
												?>
												<label style="margin-left:14px;">
													<input type="checkbox" name="selected_block_posts[]" value="<?php echo esc_attr( $bpost->ID ); ?>" checked />
													<strong><?php echo esc_html( $bpost->post_title ? $bpost->post_title : $bpost->post_name ); ?></strong>
													<code style="font-size:11px;color:#2271b1;">[<?php echo esc_html( $pt ); ?> | slug: <?php echo esc_html( $bpost->post_name ); ?> | theme: <?php echo esc_html( $theme_origin ); ?>]</code>
												</label>
											<?php endforeach; ?>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
						</div>

						<!-- PLUGINS -->
						<div class="tsbb-section">
							<div class="tsbb-section-header">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-plugins-list" name="backup_plugins_enabled" value="1" checked />
									Plugins (<?php echo count( $data['plugins'] ); ?>)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-plugins-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-plugins-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-plugins-list">
								<?php foreach ( $data['plugins'] as $plugin_file => $plugin_meta ) : ?>
									<label>
										<input type="checkbox" name="selected_plugins[]" value="<?php echo esc_attr( $plugin_file ); ?>" checked />
										<?php echo esc_html( $plugin_meta['Name'] ); ?> <code style="font-size:11px;color:#666;">(v<?php echo esc_html( $plugin_meta['Version'] ); ?> - <?php echo esc_html( $plugin_file ); ?>)</code>
									</label>
								<?php endforeach; ?>
							</div>
						</div>

						<!-- THEMES -->
						<div class="tsbb-section">
							<div class="tsbb-section-header">
								<label>
									<input type="checkbox" class="tsbb-master-toggle" data-target="tsbb-themes-list" name="backup_themes_enabled" value="1" checked />
									Themes (<?php echo count( $data['themes'] ); ?>)
								</label>
								<span class="tsbb-sub-actions">
									<a onclick="tsbbToggleAll('tsbb-themes-list', true)">Select All</a> |
									<a onclick="tsbbToggleAll('tsbb-themes-list', false)">None</a>
								</span>
							</div>
							<div class="tsbb-list" id="tsbb-themes-list">
								<?php foreach ( $data['themes'] as $theme_slug => $theme_obj ) : ?>
									<label>
										<input type="checkbox" name="selected_themes[]" value="<?php echo esc_attr( $theme_slug ); ?>" checked />
										<?php echo esc_html( $theme_obj->get( 'Name' ) ); ?>
										<code style="font-size:11px;color:#666;">(<?php echo esc_html( $theme_slug ); ?>)</code>
										<?php if ( 'twentytwentyfour' === $theme_slug ) : ?>
											<span class="tsbb-badge tsbb-badge-theme">Twenty Twenty-Four</span>
										<?php endif; ?>
									</label>
								<?php endforeach; ?>
							</div>
						</div>

						<!-- DELIVERY MODE -->
						<div class="tsbb-section" style="padding:12px 14px;background:#f0f6fc;border-color:#2271b1;">
							<label style="font-weight:600;display:block;margin-bottom:6px;">Backup Output Action:</label>
							<label style="display:block;margin-bottom:4px;">
								<input type="radio" name="export_destination" value="vault_and_download" checked />
								<strong>Save to Server Vault &amp; Download (.zip)</strong> (Recommended — keeps a copy in Server Vault for instant 1-click restore)
							</label>
							<label style="display:block;">
								<input type="radio" name="export_destination" value="vault_only" />
								<strong>Save to Server Vault Only</strong> (Best for huge backups with many Plugins/Themes)
							</label>
						</div>

						<p class="submit">
							<button type="submit" class="button button-primary button-hero">
								<span class="dashicons dashicons-download" style="margin-top:6px;margin-right:6px;"></span> Generate Full Backup (.zip)
							</button>
						</p>
					</form>
				</div>

				<!-- IMPORT / RESTORE COLUMN -->
				<div class="tsbb-card">
					<h2>
						<span>2. Restore / Import Backup (.zip)</span>
					</h2>

					<form id="tsbb-restore-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="tsbb_import_backup" />
						<input type="hidden" name="vault_filename" id="tsbb-vault-filename" value="" />
						<?php wp_nonce_field( 'tsbb_import_nonce', 'tsbb_import_nonce_field' ); ?>

						<!-- OPTION A: SERVER VAULT BACKUPS (ZERO UPLOAD LIMIT) -->
						<div class="tsbb-section" style="border-color:#00a32a;">
							<div class="tsbb-section-header" style="background:#edfaef;">
								<span>Option A: Select From Server Backup Vault (Instant — Bypass Upload Limits)</span>
							</div>
							<div class="tsbb-list" style="max-height:220px;">
								<?php if ( empty( $vault_backups ) ) : ?>
									<p style="margin:4px 0;color:#666;"><em>No backups saved in <code>wp-content/uploads/tsbb-backups/</code> yet. Generate a backup on the left or upload a <code>.zip</code> file below!</em></p>
								<?php else : ?>
									<table class="tsbb-vault-table">
										<thead>
											<tr>
												<th>Select</th>
												<th>Backup File</th>
												<th>Size</th>
												<th>Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ( $vault_backups as $idx => $vb ) : ?>
												<tr>
													<td>
														<input type="radio" name="selected_vault_radio" value="<?php echo esc_attr( $vb['filename'] ); ?>" <?php checked( 0 === $idx ); ?> onchange="document.getElementById('tsbb-vault-filename').value = this.value;" />
													</td>
													<td>
														<strong><?php echo esc_html( $vb['filename'] ); ?></strong><br/>
														<span style="font-size:11px;color:#666;"><?php echo esc_html( gmdate( 'Y-m-d H:i:s', $vb['mtime'] ) ); ?> UTC</span>
													</td>
													<td><code><?php echo esc_html( size_format( $vb['size'] ) ); ?></code></td>
													<td>
														<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=tsbb_download_vault_file&file=' . rawurlencode( $vb['filename'] ) ), 'tsbb_vault_action' ) ); ?>">Download</a>
														<a class="button button-small" style="color:#b32d2e;border-color:#b32d2e;" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=tsbb_delete_vault_file&file=' . rawurlencode( $vb['filename'] ) ), 'tsbb_vault_action' ) ); ?>" onclick="return confirm('Delete this backup archive from Server Vault?');">Delete</a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
									<script>
										document.getElementById('tsbb-vault-filename').value = <?php echo wp_json_encode( $vault_backups[0]['filename'] ); ?>;
									</script>
								<?php endif; ?>
							</div>
						</div>

						<!-- OPTION B: UPLOAD EXTERNAL ZIP (CHUNKED UPLOAD BYPASSES PHP UPLOAD_MAX_FILESIZE) -->
						<div class="tsbb-section" style="padding:14px;background:#fff;">
							<label style="font-weight:600;display:block;margin-bottom:6px;">
								Option B: Or Upload Backup <code>.zip</code> File from Computer
								<span style="font-weight:normal;font-size:12px;color:#666;">(Server limit: <?php echo esc_html( $max_upload ); ?> — Auto-Chunked Upload Enabled for Large Files!)</span>
							</label>
							<input type="file" id="tsbb-file-input" name="backup_zip_file" accept=".zip,application/zip,application/x-zip-compressed" style="width:100%;padding:8px;border:1px dashed #2271b1;background:#f6f7f7;" />
							<div class="tsbb-progress-wrap" id="tsbb-progress-wrap">
								<div class="tsbb-progress-bar" id="tsbb-progress-bar">0%</div>
							</div>
							<p id="tsbb-upload-status" style="font-size:12px;color:#135e96;margin:6px 0 0 0;display:none;"></p>
						</div>

						<div class="tsbb-section">
							<div class="tsbb-section-header">Components to Restore from Archive</div>
							<div class="tsbb-list" style="max-height:none;">
								<label><input type="checkbox" name="restore_categories" value="1" checked /> <strong>Categories</strong> (Hierarchy, slugs, descriptions &amp; term meta)</label>
								<label><input type="checkbox" name="restore_posts" value="1" checked /> <strong>Posts</strong> (Content, Gutenberg blocks, postmeta &amp; category assignments)</label>
								<label><input type="checkbox" name="restore_pages" value="1" checked /> <strong>Pages</strong> (Content, templates, hierarchy &amp; postmeta)</label>
								<label><input type="checkbox" name="restore_block_customizations" value="1" checked /> <strong>Theme Customization Codes &amp; Block Templates</strong> (Header, Footer, Single Post Area, Twenty Twenty-Four <code>wp_template</code>, <code>wp_template_part</code>, <code>wp_global_styles</code>, <code>wp_navigation</code>, <code>wp_block</code> &amp; Theme Mods)</label>
								<label><input type="checkbox" name="restore_plugins" value="1" checked /> <strong>Plugins</strong> (Extract plugin folders to <code>wp-content/plugins/</code>)</label>
								<label><input type="checkbox" name="restore_themes" value="1" checked /> <strong>Themes</strong> (Extract theme folders to <code>wp-content/themes/</code>)</label>
							</div>
						</div>

						<div class="tsbb-section">
							<div class="tsbb-section-header">Conflict Resolution Mode</div>
							<div class="tsbb-list" style="max-height:none;">
								<label>
									<input type="radio" name="conflict_mode" value="overwrite" checked />
									<strong>Overwrite Existing Items</strong> (Updates matching slugs/templates in-place — recommended for restoring Header/Footer/Single Post Block customizations)
								</label>
								<label>
									<input type="radio" name="conflict_mode" value="skip" />
									<strong>Skip Existing Items</strong> (Only import missing Posts, Pages, Categories, or Block Templates)
								</label>
							</div>
						</div>

						<p class="submit">
							<button type="submit" id="tsbb-restore-btn" class="button button-primary button-hero" style="background:#00a32a;border-color:#00a32a;">
								<span class="dashicons dashicons-upload" style="margin-top:6px;margin-right:6px;"></span> Restore Selected Backup Now
							</button>
						</p>
					</form>
				</div>
			</div>

			<div id="tsbb-support-box" class="tsbb-support-box" style="position:relative;margin:18px 0 8px;padding:10px 12px;background:#fff;border:1px solid #dcdcde;border-radius:5px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;max-width:100%;">
				<div style="color:#50575e;font-size:12px;line-height:1.6;">
					Made with <span style="color:#d63638;" aria-label="love">&#10084;</span> by <a href="https://github.com/androidSuperUser" target="_blank" rel="noopener noreferrer"><strong>androidSuperUser</strong></a> <span style="color:#646970;">&middot; Version 1.0 Stable</span>
				</div>
				<div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding-right:24px;">
					<a class="button button-small" href="https://github.com/androidSuperUser" target="_blank" rel="noopener noreferrer">GitHub</a>
					<a class="button button-primary button-small" href="https://paypal.me/paymenttomanu" target="_blank" rel="noopener noreferrer">Support development</a>
				</div>
				<button type="button" id="tsbb-dismiss-support" aria-label="Dismiss developer support box" title="Dismiss" style="position:absolute;top:5px;right:5px;border:0;background:transparent;color:#646970;font-size:18px;line-height:1;cursor:pointer;padding:2px 5px;">&times;</button>
			</div>
			<script>
			(function() {
				var box = document.getElementById('tsbb-support-box');
				var close = document.getElementById('tsbb-dismiss-support');
				var key = 'tsbbSupportBoxDismissed';
				try { if (window.localStorage.getItem(key) === '1' && box) box.style.display = 'none'; } catch (e) {}
				if (close && box) {
					close.addEventListener('click', function() {
						box.style.display = 'none';
						try { window.localStorage.setItem(key, '1'); } catch (e) {}
					});
				}
			})();
			</script>

			<script>
				function tsbbToggleAll(containerId, state) {
					var container = document.getElementById(containerId);
					if (!container) return;
					var checkboxes = container.querySelectorAll('input[type="checkbox"]');
					checkboxes.forEach(function(cb) { cb.checked = state; });
				}
				document.querySelectorAll('.tsbb-master-toggle').forEach(function(master) {
					master.addEventListener('change', function() {
						var targetId = this.getAttribute('data-target');
						tsbbToggleAll(targetId, this.checked);
					});
				});

				// When user selects a local file, automatically use chunked AJAX uploader so PHP upload_max_filesize / post_max_size NEVER blocks it!
				(function() {
					var form = document.getElementById('tsbb-restore-form');
					var fileInput = document.getElementById('tsbb-file-input');
					var vaultInput = document.getElementById('tsbb-vault-filename');
					var progressWrap = document.getElementById('tsbb-progress-wrap');
					var progressBar = document.getElementById('tsbb-progress-bar');
					var statusText = document.getElementById('tsbb-upload-status');
					var restoreBtn = document.getElementById('tsbb-restore-btn');
					var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
					var chunkNonce = <?php echo wp_json_encode( wp_create_nonce( 'tsbb_chunk_nonce' ) ); ?>;

					fileInput.addEventListener('change', function() {
						if (fileInput.files && fileInput.files.length > 0) {
							// Uncheck vault radio buttons when a local file is chosen
							var radios = document.querySelectorAll('input[name="selected_vault_radio"]');
							radios.forEach(function(r) { r.checked = false; });
						}
					});

					form.addEventListener('submit', function(e) {
						if (!fileInput.files || fileInput.files.length === 0) {
							// Using Vault selection directly
							if (!vaultInput.value) {
								e.preventDefault();
								alert('Please either select a backup from the Server Vault or choose a .zip file from your computer.');
							}
							return;
						}

						// Intercept local file submission and upload in 1MB chunks via AJAX to Server Vault first
						e.preventDefault();
						var file = fileInput.files[0];
						var chunkSize = 1024 * 1024; // 1 MB chunks (safe on almost all servers)
						var totalChunks = Math.ceil(file.size / chunkSize);
						var currentChunk = 0;
						var targetName = 'uploaded-' + Date.now() + '-' + file.name.replace(/[^a-zA-Z0-9._-]/g, '');

						restoreBtn.disabled = true;
						progressWrap.style.display = 'block';
						statusText.style.display = 'block';
						statusText.textContent = 'Uploading backup in safe 1MB chunks to bypass PHP size limits...';

						function uploadNextChunk() {
							var start = currentChunk * chunkSize;
							var end = Math.min(start + chunkSize, file.size);
							var blob = file.slice(start, end);

							var formData = new FormData();
							formData.append('action', 'tsbb_upload_chunk');
							formData.append('nonce', chunkNonce);
							formData.append('file_name', targetName);
							formData.append('chunk_index', currentChunk);
							formData.append('total_chunks', totalChunks);
							formData.append('chunk_file', blob, 'chunk.bin');

							fetch(ajaxUrl, {
								method: 'POST',
								body: formData,
								credentials: 'same-origin'
							})
							.then(function(res) { return res.json(); })
							.then(function(data) {
								if (!data || !data.success) {
									var errMsg = (data && data.data) ? data.data : 'Chunk upload failed.';
									alert('Upload Error: ' + errMsg);
									restoreBtn.disabled = false;
									return;
								}
								currentChunk++;
								var pct = Math.round((currentChunk / totalChunks) * 100);
								progressBar.style.width = pct + '%';
								progressBar.textContent = pct + '%';

								if (currentChunk < totalChunks) {
									uploadNextChunk();
								} else {
									statusText.textContent = 'Upload complete! Starting restore...';
									// Clear file input so browser doesn't re-post the huge file and exceed post_max_size
									fileInput.value = '';
									vaultInput.value = targetName;
									form.submit();
								}
							})
							.catch(function(err) {
								alert('Network error during chunked upload: ' + err);
								restoreBtn.disabled = false;
							});
						}

						uploadNextChunk();
					});
				})();
			</script>
		</div>
		<?php
	}

	/**
	 * AJAX Handler: Receive 1MB chunks and assemble into Server Vault
	 */
	public function ajax_upload_chunk() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}
		check_ajax_referer( 'tsbb_chunk_nonce', 'nonce' );

		$file_name    = isset( $_POST['file_name'] ) ? sanitize_file_name( wp_unslash( $_POST['file_name'] ) ) : '';
		$chunk_index  = isset( $_POST['chunk_index'] ) ? intval( $_POST['chunk_index'] ) : 0;

		if ( empty( $file_name ) || empty( $_FILES['chunk_file']['tmp_name'] ) ) {
			wp_send_json_error( 'Missing chunk data.' );
		}

		// Ensure .zip extension
		if ( substr( strtolower( $file_name ), -4 ) !== '.zip' ) {
			$file_name .= '.zip';
		}

		$vault_dir = $this->get_vault_dir();
		$dest_path = trailingslashit( $vault_dir ) . $file_name;

		$mode = ( 0 === $chunk_index ) ? 'wb' : 'ab';
		// PHP streams are required here to append 1 MB chunks without loading the entire archive into memory.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- WP_Filesystem has no streaming append API; this avoids loading large backup archives into memory.
		$out  = @fopen( $dest_path, $mode );
		if ( ! $out ) {
			wp_send_json_error( 'Cannot open destination file in Server Vault for writing.' );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Read the temporary upload as a stream to keep memory use bounded.
		$in = @fopen( $_FILES['chunk_file']['tmp_name'], 'rb' );
		if ( ! $in ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the PHP stream opened above.
			fclose( $out );
			wp_send_json_error( 'Cannot read uploaded chunk.' );
		}

		while ( $buff = fread( $in, 8192 ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Stream upload chunks without loading the whole file into memory.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Append streamed upload bytes to the destination archive.
			fwrite( $out, $buff );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the temporary upload stream.
		fclose( $in );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the archive append stream.
		fclose( $out );

		wp_send_json_success( array(
			'file_name'   => $file_name,
			'chunk_index' => $chunk_index,
		) );
	}

	/**
	 * Download a backup file from the Server Vault
	 */
	public function handle_download_vault_file() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized.' );
		}
		check_admin_referer( 'tsbb_vault_action' );

		$file = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		$path = trailingslashit( $this->get_vault_dir() ) . $file;

		if ( empty( $file ) || ! file_exists( $path ) ) {
			$this->redirect_with_message( 'Backup file not found in Server Vault.', 'error' );
		}

		$this->stream_zip_download( $path, $file, false );
	}

	/**
	 * Delete a backup file from the Server Vault
	 */
	public function handle_delete_vault_file() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized.' );
		}
		check_admin_referer( 'tsbb_vault_action' );

		$file = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		$path = trailingslashit( $this->get_vault_dir() ) . $file;

		if ( ! empty( $file ) && file_exists( $path ) ) {
			wp_delete_file( $path );
			$this->redirect_with_message( 'Deleted backup archive: ' . $file, 'success' );
		}
		$this->redirect_with_message( 'Could not find file to delete.', 'error' );
	}

	/**
	 * Cleanly stream a ZIP file to the browser (flushes output buffers so PHP warnings/spaces never corrupt the ZIP header)
	 */
	private function stream_zip_download( $zip_filepath, $zip_filename, $delete_after = false ) {
		while ( ob_get_level() > 0 ) {
			@ob_end_clean();
		}

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $zip_filename . '"' );
		header( 'Content-Transfer-Encoding: binary' );
		header( 'Content-Length: ' . filesize( $zip_filepath ) );

		// Stream large ZIP downloads instead of loading the full archive into memory. WP_Filesystem does not expose a chunked read API.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Required for bounded-memory binary ZIP streaming.
		$handle = fopen( $zip_filepath, 'rb' );
		if ( $handle ) {
			while ( ! feof( $handle ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Emit the ZIP's raw binary bytes unchanged in the download response.
				$chunk = fread( $handle, 65536 );
				if ( false === $chunk ) {
					break;
				}
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ZIP bytes must not be escaped or modified.
				echo $chunk;
				flush();
			}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the streamed ZIP handle.
			fclose( $handle );
		} else {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Fallback binary response for hosts where fopen fails.
			readfile( $zip_filepath );
		}

		if ( $delete_after ) {
			wp_delete_file( $zip_filepath );
		}
		exit;
	}

	/**
	 * Serialize Post Objects + Postmeta + Taxonomies
	 */
	private function export_post_records( $post_ids ) {
		$records = array();
		foreach ( $post_ids as $pid ) {
			$post = get_post( intval( $pid ), ARRAY_A );
			if ( ! $post ) {
				continue;
			}

			$raw_meta   = get_post_meta( $post['ID'] );
			$clean_meta = array();
			if ( is_array( $raw_meta ) ) {
				foreach ( $raw_meta as $mkey => $mvals ) {
					$clean_meta[ $mkey ] = array_map( 'maybe_unserialize', $mvals );
				}
			}

			$taxonomies = get_object_taxonomies( $post['post_type'] );
			$tax_data   = array();
			foreach ( $taxonomies as $tax ) {
				$terms = wp_get_object_terms( $post['ID'], $tax );
				if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
					$tax_data[ $tax ] = array();
					foreach ( $terms as $t ) {
						$tax_data[ $tax ][] = array(
							'name'        => $t->name,
							'slug'        => $t->slug,
							'description' => $t->description,
						);
					}
				}
			}

			$records[] = array(
				'post'       => $post,
				'meta'       => $clean_meta,
				'taxonomies' => $tax_data,
			);
		}
		return $records;
	}

	/**
	 * Handle Backup Export Request
	 */
	public function handle_export_backup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized.' );
		}
		check_admin_referer( 'tsbb_export_nonce', 'tsbb_nonce' );

		@set_time_limit( 0 );
		@ini_set( 'memory_limit', '512M' );

		$manifest = array(
			'plugin_version'       => '2.0.0',
			'site_url'             => site_url(),
			'home_url'             => home_url(),
			'wp_version'           => get_bloginfo( 'version' ),
			'exported_at'          => gmdate( 'c' ),
			'active_theme'         => get_stylesheet(),
			'template_theme'       => get_template(),
			'categories'           => array(),
			'posts'                => array(),
			'pages'                => array(),
			'block_customizations' => array(
				'posts'      => array(),
				'theme_mods' => array(),
				'custom_css' => '',
			),
			'plugins_list'         => array(),
			'themes_list'          => array(),
		);

		// 1. Categories
		if ( ! empty( $_POST['backup_categories_enabled'] ) && ! empty( $_POST['selected_categories'] ) ) {
			$cat_ids = array_map( 'intval', (array) $_POST['selected_categories'] );
			foreach ( $cat_ids as $cid ) {
				$term = get_term( $cid, 'category' );
				if ( $term && ! is_wp_error( $term ) ) {
					$parent_slug = '';
					if ( $term->parent ) {
						$parent_term = get_term( $term->parent, 'category' );
						if ( $parent_term && ! is_wp_error( $parent_term ) ) {
							$parent_slug = $parent_term->slug;
						}
					}
					$raw_tmeta = get_term_meta( $term->term_id );
					$tmeta     = array();
					if ( is_array( $raw_tmeta ) ) {
						foreach ( $raw_tmeta as $k => $v ) {
							$tmeta[ $k ] = array_map( 'maybe_unserialize', $v );
						}
					}
					$manifest['categories'][] = array(
						'term_id'     => $term->term_id,
						'name'        => $term->name,
						'slug'        => $term->slug,
						'description' => $term->description,
						'parent_slug' => $parent_slug,
						'meta'        => $tmeta,
					);
				}
			}
		}

		// 2. Posts
		if ( ! empty( $_POST['backup_posts_enabled'] ) && ! empty( $_POST['selected_posts'] ) ) {
			$post_ids          = array_map( 'intval', (array) $_POST['selected_posts'] );
			$manifest['posts'] = $this->export_post_records( $post_ids );
		}

		// 3. Pages
		if ( ! empty( $_POST['backup_pages_enabled'] ) && ! empty( $_POST['selected_pages'] ) ) {
			$page_ids          = array_map( 'intval', (array) $_POST['selected_pages'] );
			$manifest['pages'] = $this->export_post_records( $page_ids );
		}

		// 4. Block Theme Customizations
		if ( ! empty( $_POST['backup_block_customizations_enabled'] ) ) {
			if ( ! empty( $_POST['selected_block_posts'] ) ) {
				$bpost_ids                                    = array_map( 'intval', (array) $_POST['selected_block_posts'] );
				$manifest['block_customizations']['posts'] = $this->export_post_records( $bpost_ids );
			}
			if ( ! empty( $_POST['include_theme_mods_and_css'] ) ) {
				$stylesheet                                     = get_stylesheet();
				$manifest['block_customizations']['theme_mods'] = array(
					'stylesheet'            => $stylesheet,
					'mods'                  => get_option( 'theme_mods_' . $stylesheet, array() ),
					'twentytwentyfour_mods' => get_option( 'theme_mods_twentytwentyfour', array() ),
					'site_icon'             => get_option( 'site_icon' ),
					'site_logo'             => get_option( 'site_logo' ),
				);
				if ( function_exists( 'wp_get_custom_css' ) ) {
					$manifest['block_customizations']['custom_css'] = wp_get_custom_css( $stylesheet );
				}
			}
		}

		// Build staging directory first so both ZipArchive and PclZip fallback work reliably even with 10,000+ plugin/theme files
		$vault_dir    = $this->get_vault_dir();
		$zip_filename = 'wp-total-backup-' . gmdate( 'Y-m-d-His' ) . '.zip';
		$zip_filepath = trailingslashit( $vault_dir ) . $zip_filename;
		$staging_dir  = trailingslashit( $vault_dir ) . 'staging-' . time() . '-' . wp_rand( 1000, 9999 );

		wp_mkdir_p( $staging_dir );

		// Copy physical Block Theme raw template files if requested
		if ( ! empty( $_POST['backup_block_customizations_enabled'] ) && ! empty( $_POST['include_theme_mods_and_css'] ) ) {
			$themes_to_snapshot = array_unique( array( get_stylesheet(), 'twentytwentyfour' ) );
			foreach ( $themes_to_snapshot as $tslug ) {
				$tdir = trailingslashit( get_theme_root( $tslug ) ) . $tslug;
				if ( is_dir( $tdir ) ) {
					foreach ( array( 'templates', 'parts', 'patterns', 'styles' ) as $subdir ) {
						$full_sub = $tdir . '/' . $subdir;
						if ( is_dir( $full_sub ) ) {
							$this->copy_directory( $full_sub, $staging_dir . '/block-theme-codes/' . $tslug . '/' . $subdir );
						}
					}
					if ( file_exists( $tdir . '/theme.json' ) ) {
						wp_mkdir_p( $staging_dir . '/block-theme-codes/' . $tslug );
						@copy( $tdir . '/theme.json', $staging_dir . '/block-theme-codes/' . $tslug . '/theme.json' );
					}
				}
			}
		}

		// 5. Plugins
		if ( ! empty( $_POST['backup_plugins_enabled'] ) && ! empty( $_POST['selected_plugins'] ) ) {
			$selected_plugins = array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['selected_plugins'] ) );
			foreach ( $selected_plugins as $plugin_file ) {
				$manifest['plugins_list'][] = $plugin_file;
				$plugin_dir                 = dirname( $plugin_file );
				if ( '.' === $plugin_dir ) {
					$full_path = trailingslashit( WP_PLUGIN_DIR ) . $plugin_file;
					if ( file_exists( $full_path ) ) {
						wp_mkdir_p( $staging_dir . '/plugins' );
						@copy( $full_path, $staging_dir . '/plugins/' . $plugin_file );
					}
				} else {
					$full_dir = trailingslashit( WP_PLUGIN_DIR ) . $plugin_dir;
					if ( is_dir( $full_dir ) ) {
						$this->copy_directory( $full_dir, $staging_dir . '/plugins/' . $plugin_dir );
					}
				}
			}
		}

		// 6. Themes
		if ( ! empty( $_POST['backup_themes_enabled'] ) && ! empty( $_POST['selected_themes'] ) ) {
			$selected_themes = array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['selected_themes'] ) );
			foreach ( $selected_themes as $theme_slug ) {
				$manifest['themes_list'][] = $theme_slug;
				$theme_dir                 = trailingslashit( get_theme_root( $theme_slug ) ) . $theme_slug;
				if ( is_dir( $theme_dir ) ) {
					$this->copy_directory( $theme_dir, $staging_dir . '/themes/' . $theme_slug );
				}
			}
		}

		// Write backup-manifest.json at root of staging folder
		$manifest_json = wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		file_put_contents( trailingslashit( $staging_dir ) . 'backup-manifest.json', $manifest_json );

		// Pack staging folder into $zip_filepath using ZipArchive or PclZip fallback
		$packed = $this->create_zip_from_directory( $staging_dir, $zip_filepath );
		$this->recursive_rmdir( $staging_dir );

		if ( ! $packed || ! file_exists( $zip_filepath ) ) {
			$this->redirect_with_message( 'Failed to build ZIP archive. Check disk space and permissions in wp-content/uploads/.', 'error' );
		}

		$destination = isset( $_POST['export_destination'] ) ? sanitize_text_field( wp_unslash( $_POST['export_destination'] ) ) : 'vault_and_download';
		if ( 'vault_only' === $destination ) {
			$this->redirect_with_message( 'Backup saved to Server Vault: ' . $zip_filename . ' (' . size_format( filesize( $zip_filepath ) ) . '). You can restore or download it from Option A on the right!', 'success' );
		}

		// Stream file download while keeping the copy in Server Vault for easy 1-click restore
		$this->stream_zip_download( $zip_filepath, $zip_filename, false );
	}

	/**
	 * Build a valid ZIP archive from a staging directory using ZipArchive (with batch flushing) or PclZip fallback
	 */
	private function create_zip_from_directory( $source_dir, $zip_filepath ) {
		$source_dir = rtrim( realpath( $source_dir ), '/\\' );
		if ( ! $source_dir || ! is_dir( $source_dir ) ) {
			return false;
		}

		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( $zip->open( $zip_filepath, ZipArchive::CREATE | ZipArchive::OVERWRITE ) === true ) {
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::SELF_FIRST
				);

				$count = 0;
				foreach ( $iterator as $item ) {
					$item_path = $item->getRealPath();
					if ( ! $item_path ) {
						continue;
					}
					$relative = substr( $item_path, strlen( $source_dir ) + 1 );
					$relative = str_replace( '\\', '/', $relative );

					if ( $item->isDir() ) {
						$zip->addEmptyDir( $relative );
					} else {
						$zip->addFile( $item_path, $relative );
						$count++;
						// Flush every 250 files so OS file descriptor limit is never exceeded
						if ( 0 === $count % 250 ) {
							$zip->close();
							$zip->open( $zip_filepath );
						}
					}
				}
				$closed = $zip->close();
				if ( $closed && file_exists( $zip_filepath ) && filesize( $zip_filepath ) > 0 ) {
					return true;
				}
			}
		}

		// Fallback to WordPress built-in PclZip
		if ( ! class_exists( 'PclZip' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		}
		$archive = new PclZip( $zip_filepath );
		$result  = $archive->create( $source_dir, PCLZIP_OPT_REMOVE_PATH, $source_dir );
		return ( 0 !== $result && file_exists( $zip_filepath ) );
	}

	/**
	 * Extract a ZIP archive to a destination directory using ZipArchive or PclZip fallback
	 */
	private function is_safe_archive_entry_name( $name ) {
		$name = str_replace( '\\', '/', (string) $name );
		if ( '' === $name || false !== strpos( $name, "\0" ) || '/' === substr( $name, 0, 1 ) || preg_match( '/^[A-Za-z]:\//', $name ) ) {
			return false;
		}
		foreach ( explode( '/', $name ) as $segment ) {
			if ( '..' === $segment ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Extract a ZIP archive only after validating every member path.
	 */
	private function extract_zip_to_directory( $zip_filepath, $extract_dir ) {
		wp_mkdir_p( $extract_dir );

		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( $zip->open( $zip_filepath ) === true ) {
				for ( $index = 0; $index < $zip->numFiles; $index++ ) {
					$entry_name = $zip->getNameIndex( $index );
					if ( ! $this->is_safe_archive_entry_name( $entry_name ) ) {
						$zip->close();
						return false;
					}
				}
				$extracted = $zip->extractTo( $extract_dir );
				$zip->close();
				if ( $extracted ) {
					return true;
				}
			}
		}

		// Fallback to WordPress built-in PclZip.
		if ( ! class_exists( 'PclZip' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		}
		$archive = new PclZip( $zip_filepath );
		$entries = $archive->listContent();
		if ( ! is_array( $entries ) || empty( $entries ) ) {
			return false;
		}
		foreach ( $entries as $entry ) {
			if ( empty( $entry['filename'] ) || ! $this->is_safe_archive_entry_name( $entry['filename'] ) ) {
				return false;
			}
		}
		$result = $archive->extract( PCLZIP_OPT_PATH, $extract_dir );
		return ( is_array( $result ) && ! empty( $result ) );
	}

	/**
	 * Locate backup-manifest.json even if user re-zipped the backup inside a subfolder
	 */
	private function find_manifest_root( $extract_dir ) {
		if ( file_exists( trailingslashit( $extract_dir ) . 'backup-manifest.json' ) ) {
			return $extract_dir;
		}
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $extract_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);
		foreach ( $iterator as $item ) {
			if ( $item->isFile() && 'backup-manifest.json' === $item->getFilename() ) {
				return dirname( $item->getRealPath() );
			}
		}
		return false;
	}

	/**
	 * Describe PHP $_FILES upload error codes clearly
	 */
	private function get_upload_error_message( $error_code ) {
		switch ( $error_code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return 'The uploaded .zip file exceeds your server PHP upload_max_filesize (' . size_format( wp_max_upload_size() ) . '). Please keep JavaScript enabled for automatic 1MB chunked upload, or select the backup from Option A (Server Vault).';
			case UPLOAD_ERR_PARTIAL:
				return 'The .zip file was only partially uploaded.';
			case UPLOAD_ERR_NO_FILE:
				return 'No .zip file was selected and no Server Vault backup was chosen.';
			case UPLOAD_ERR_NO_TMP_DIR:
				return 'Server is missing a temporary upload folder.';
			case UPLOAD_ERR_CANT_WRITE:
				return 'Failed to write uploaded file to disk.';
			default:
				return 'Unknown upload error (code ' . intval( $error_code ) . ').';
		}
	}

	/**
	 * Handle Backup Import / Restore Request
	 */
	public function handle_import_backup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized.' );
		}

		// Detect when PHP silently drops $_POST and $_FILES because post_max_size was exceeded
		if ( empty( $_POST ) && empty( $_FILES ) && isset( $_SERVER['CONTENT_LENGTH'] ) && intval( $_SERVER['CONTENT_LENGTH'] ) > 0 ) {
			$this->redirect_with_message( 'Upload exceeded PHP post_max_size limit! Please use Option A (Server Backup Vault) or let the automatic chunked uploader finish.', 'error' );
		}

		check_admin_referer( 'tsbb_import_nonce', 'tsbb_import_nonce_field' );

		@set_time_limit( 0 );
		@ini_set( 'memory_limit', '512M' );

		$zip_source_path = '';

		// Priority 1: Direct upload in $_FILES if provided
		if ( ! empty( $_FILES['backup_zip_file']['name'] ) ) {
			if ( ! empty( $_FILES['backup_zip_file']['error'] ) && UPLOAD_ERR_OK !== intval( $_FILES['backup_zip_file']['error'] ) ) {
				$this->redirect_with_message( $this->get_upload_error_message( intval( $_FILES['backup_zip_file']['error'] ) ), 'error' );
			}
			if ( ! empty( $_FILES['backup_zip_file']['tmp_name'] ) && is_uploaded_file( $_FILES['backup_zip_file']['tmp_name'] ) ) {
				$zip_source_path = $_FILES['backup_zip_file']['tmp_name'];
			}
		}

		// Priority 2: Server Vault filename (either chosen via radio button or uploaded via Chunked Uploader)
		if ( empty( $zip_source_path ) ) {
			$vault_file = '';
			if ( ! empty( $_POST['vault_filename'] ) ) {
				$vault_file = sanitize_file_name( wp_unslash( $_POST['vault_filename'] ) );
			} elseif ( ! empty( $_POST['selected_vault_radio'] ) ) {
				$vault_file = sanitize_file_name( wp_unslash( $_POST['selected_vault_radio'] ) );
			}
			if ( ! empty( $vault_file ) ) {
				$candidate = trailingslashit( $this->get_vault_dir() ) . $vault_file;
				if ( file_exists( $candidate ) ) {
					$zip_source_path = $candidate;
				}
			}
		}

		if ( empty( $zip_source_path ) || ! file_exists( $zip_source_path ) ) {
			$this->redirect_with_message( 'Please select a backup from Option A (Server Vault) or choose a valid .zip backup file from your computer.', 'error' );
		}

		$upload_dir  = wp_upload_dir();
		$extract_dir = trailingslashit( $upload_dir['basedir'] ) . 'tsbb-restore-tmp-' . time() . '-' . wp_rand( 100, 999 );

		if ( ! $this->extract_zip_to_directory( $zip_source_path, $extract_dir ) ) {
			$this->recursive_rmdir( $extract_dir );
			$this->redirect_with_message( 'Failed to extract ZIP archive. Make sure the file is a valid .zip archive.', 'error' );
		}

		$bundle_root = $this->find_manifest_root( $extract_dir );
		if ( ! $bundle_root ) {
			$this->recursive_rmdir( $extract_dir );
			$this->redirect_with_message( 'Invalid backup archive: backup-manifest.json was not found inside the ZIP.', 'error' );
		}

		$manifest_file = trailingslashit( $bundle_root ) . 'backup-manifest.json';
		$manifest      = json_decode( file_get_contents( $manifest_file ), true );
		if ( ! is_array( $manifest ) ) {
			$this->recursive_rmdir( $extract_dir );
			$this->redirect_with_message( 'Corrupted backup-manifest.json file.', 'error' );
		}

		$conflict_mode = isset( $_POST['conflict_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['conflict_mode'] ) ) : 'overwrite';
		$stats         = array(
			'categories' => 0,
			'posts'      => 0,
			'pages'      => 0,
			'blocks'     => 0,
			'plugins'    => 0,
			'themes'     => 0,
		);

		// 1. Restore Categories
		if ( ! empty( $_POST['restore_categories'] ) && ! empty( $manifest['categories'] ) ) {
			foreach ( $manifest['categories'] as $cat ) {
				$existing = get_term_by( 'slug', $cat['slug'], 'category' );
				if ( $existing && ! is_wp_error( $existing ) ) {
					if ( 'overwrite' === $conflict_mode ) {
						wp_update_term( $existing->term_id, 'category', array(
							'name'        => $cat['name'],
							'description' => $cat['description'],
						) );
						$term_id = $existing->term_id;
						$stats['categories']++;
					} else {
						$term_id = $existing->term_id;
					}
				} else {
					$inserted = wp_insert_term( $cat['name'], 'category', array(
						'slug'        => $cat['slug'],
						'description' => $cat['description'],
					) );
					$term_id = ! is_wp_error( $inserted ) ? $inserted['term_id'] : 0;
					if ( $term_id ) {
						$stats['categories']++;
					}
				}

				if ( $term_id && ! empty( $cat['meta'] ) && is_array( $cat['meta'] ) ) {
					foreach ( $cat['meta'] as $mkey => $mvals ) {
						delete_term_meta( $term_id, $mkey );
						foreach ( (array) $mvals as $mval ) {
							add_term_meta( $term_id, $mkey, $mval );
						}
					}
				}
			}

			foreach ( $manifest['categories'] as $cat ) {
				if ( ! empty( $cat['parent_slug'] ) ) {
					$child_term  = get_term_by( 'slug', $cat['slug'], 'category' );
					$parent_term = get_term_by( 'slug', $cat['parent_slug'], 'category' );
					if ( $child_term && $parent_term && ! is_wp_error( $child_term ) && ! is_wp_error( $parent_term ) ) {
						wp_update_term( $child_term->term_id, 'category', array( 'parent' => $parent_term->term_id ) );
					}
				}
			}
		}

		// 2. Restore Posts
		if ( ! empty( $_POST['restore_posts'] ) && ! empty( $manifest['posts'] ) ) {
			foreach ( $manifest['posts'] as $record ) {
				if ( $this->restore_single_post_record( $record, $conflict_mode ) ) {
					$stats['posts']++;
				}
			}
		}

		// 3. Restore Pages
		if ( ! empty( $_POST['restore_pages'] ) && ! empty( $manifest['pages'] ) ) {
			foreach ( $manifest['pages'] as $record ) {
				if ( $this->restore_single_post_record( $record, $conflict_mode ) ) {
					$stats['pages']++;
				}
			}
		}

		// 4. Restore Block Theme Customizations
		if ( ! empty( $_POST['restore_block_customizations'] ) && ! empty( $manifest['block_customizations'] ) ) {
			$bdata = $manifest['block_customizations'];
			if ( ! empty( $bdata['posts'] ) && is_array( $bdata['posts'] ) ) {
				foreach ( $bdata['posts'] as $record ) {
					if ( $this->restore_single_post_record( $record, $conflict_mode, true ) ) {
						$stats['blocks']++;
					}
				}
			}

			if ( ! empty( $bdata['theme_mods'] ) ) {
				$tmods = $bdata['theme_mods'];
				if ( ! empty( $tmods['stylesheet'] ) && ! empty( $tmods['mods'] ) ) {
					update_option( 'theme_mods_' . $tmods['stylesheet'], $tmods['mods'] );
				}
				if ( ! empty( $tmods['twentytwentyfour_mods'] ) ) {
					update_option( 'theme_mods_twentytwentyfour', $tmods['twentytwentyfour_mods'] );
				}
			}
			if ( ! empty( $bdata['custom_css'] ) && function_exists( 'wp_update_custom_css_post' ) ) {
				wp_update_custom_css_post( $bdata['custom_css'] );
			}

			$raw_blocks_dir = trailingslashit( $bundle_root ) . 'block-theme-codes';
			if ( is_dir( $raw_blocks_dir ) && 'overwrite' === $conflict_mode ) {
				$this->copy_directory( $raw_blocks_dir, get_theme_root() );
			}
		}

		// 5. Restore Plugins
		if ( ! empty( $_POST['restore_plugins'] ) ) {
			$plugins_src = trailingslashit( $bundle_root ) . 'plugins';
			if ( is_dir( $plugins_src ) ) {
				$this->copy_directory( $plugins_src, WP_PLUGIN_DIR );
				$stats['plugins'] = ! empty( $manifest['plugins_list'] ) ? count( $manifest['plugins_list'] ) : 1;
			}
		}

		// 6. Restore Themes
		if ( ! empty( $_POST['restore_themes'] ) ) {
			$themes_src = trailingslashit( $bundle_root ) . 'themes';
			if ( is_dir( $themes_src ) ) {
				$this->copy_directory( $themes_src, get_theme_root() );
				$stats['themes'] = ! empty( $manifest['themes_list'] ) ? count( $manifest['themes_list'] ) : 1;
			}
		}

		$this->recursive_rmdir( $extract_dir );

		wp_cache_flush();
		flush_rewrite_rules();

		$summary = sprintf(
			'Restore completed! Restored: %d Categories, %d Posts, %d Pages, %d Block Theme Customizations, %d Plugins, %d Themes.',
			$stats['categories'],
			$stats['posts'],
			$stats['pages'],
			$stats['blocks'],
			$stats['plugins'],
			$stats['themes']
		);

		$this->redirect_with_message( $summary, 'success' );
	}

	/**
	 * Restore a single Post / Page / Block Template record
	 */
	private function restore_single_post_record( $record, $conflict_mode = 'overwrite', $is_block_entity = false ) {
		if ( empty( $record['post'] ) || ! is_array( $record['post'] ) ) {
			return false;
		}

		$post_arr  = $record['post'];
		$post_type = $post_arr['post_type'];
		$post_name = $post_arr['post_name'];

		$existing_id = 0;
		$candidates  = get_posts( array(
			'name'           => $post_name,
			'post_type'      => $post_type,
			'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future', 'auto-draft' ),
			'posts_per_page' => -1,
		) );

		if ( ! empty( $candidates ) ) {
			if ( $is_block_entity && ! empty( $record['taxonomies']['wp_theme'] ) ) {
				$target_theme_slug = $record['taxonomies']['wp_theme'][0]['slug'];
				foreach ( $candidates as $cand ) {
					$cand_themes = wp_get_post_terms( $cand->ID, 'wp_theme', array( 'fields' => 'slugs' ) );
					if ( ! is_wp_error( $cand_themes ) && in_array( $target_theme_slug, $cand_themes, true ) ) {
						$existing_id = $cand->ID;
						break;
					}
				}
			}
			if ( ! $existing_id ) {
				$existing_id = $candidates[0]->ID;
			}
		}

		if ( $existing_id && 'skip' === $conflict_mode ) {
			return false;
		}

		$insert_data = array(
			'post_title'   => $post_arr['post_title'],
			'post_name'    => $post_arr['post_name'],
			'post_content' => wp_slash( $post_arr['post_content'] ),
			'post_excerpt' => wp_slash( $post_arr['post_excerpt'] ),
			'post_status'  => $post_arr['post_status'],
			'post_type'    => $post_arr['post_type'],
			'post_date'    => $post_arr['post_date'],
			'menu_order'   => intval( $post_arr['menu_order'] ),
		);

		if ( $existing_id ) {
			$insert_data['ID'] = $existing_id;
			$new_post_id       = wp_update_post( $insert_data, true );
		} else {
			$new_post_id = wp_insert_post( $insert_data, true );
		}

		if ( is_wp_error( $new_post_id ) || ! $new_post_id ) {
			return false;
		}

		if ( ! empty( $record['meta'] ) && is_array( $record['meta'] ) ) {
			foreach ( $record['meta'] as $mkey => $mvals ) {
				if ( '_edit_lock' === $mkey || '_edit_last' === $mkey ) {
					continue;
				}
				delete_post_meta( $new_post_id, $mkey );
				foreach ( (array) $mvals as $mval ) {
					add_post_meta( $new_post_id, $mkey, $mval );
				}
			}
		}

		if ( ! empty( $record['taxonomies'] ) && is_array( $record['taxonomies'] ) ) {
			foreach ( $record['taxonomies'] as $tax => $terms ) {
				if ( ! taxonomy_exists( $tax ) ) {
					continue;
				}
				$term_ids = array();
				foreach ( $terms as $t ) {
					$existing_term = get_term_by( 'slug', $t['slug'], $tax );
					if ( $existing_term && ! is_wp_error( $existing_term ) ) {
						$term_ids[] = intval( $existing_term->term_id );
					} else {
						$created = wp_insert_term( $t['name'], $tax, array(
							'slug'        => $t['slug'],
							'description' => isset( $t['description'] ) ? $t['description'] : '',
						) );
						if ( ! is_wp_error( $created ) && ! empty( $created['term_id'] ) ) {
							$term_ids[] = intval( $created['term_id'] );
						}
					}
				}
				wp_set_object_terms( $new_post_id, $term_ids, $tax, false );
			}
		}

		return true;
	}

	/**
	 * Copy directory recursively
	 */
	private function copy_directory( $src, $dst ) {
		$src = rtrim( realpath( $src ), '/\\' );
		if ( ! $src || ! is_dir( $src ) ) {
			return;
		}
		wp_mkdir_p( $dst );

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $src, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iterator as $item ) {
			$item_path = $item->getRealPath();
			if ( ! $item_path ) {
				continue;
			}
			$relative    = substr( $item_path, strlen( $src ) + 1 );
			$target_path = trailingslashit( $dst ) . $relative;
			if ( $item->isDir() ) {
				wp_mkdir_p( $target_path );
			} else {
				wp_mkdir_p( dirname( $target_path ) );
				@copy( $item_path, $target_path );
			}
		}
	}

	/**
	 * Recursively remove temporary directory
	 */
	private function recursive_rmdir( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			return;
		}

		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);
		foreach ( $items as $item ) {
			$item_path = $item->getRealPath();
			if ( ! $item_path ) {
				continue;
			}
			if ( $item->isDir() ) {
				$wp_filesystem->rmdir( $item_path );
			} else {
				wp_delete_file( $item_path );
			}
		}
		$wp_filesystem->rmdir( $dir );
	}


	/**
	 * Redirect back to plugin admin page with notice
	 */
	private function redirect_with_message( $msg, $type = 'success' ) {
		$url = add_query_arg(
			array(
				'page'      => 'total-site-backup',
				'tsbb_msg'  => rawurlencode( $msg ),
				'tsbb_type' => $type,
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}
}

new Total_Site_Block_Backup_Plugin();